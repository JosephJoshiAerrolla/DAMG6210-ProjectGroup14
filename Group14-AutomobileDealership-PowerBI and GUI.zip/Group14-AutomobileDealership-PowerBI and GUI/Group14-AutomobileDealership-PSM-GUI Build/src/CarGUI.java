import javax.swing.*;
import java.awt.event.ActionEvent;

public class CarGUI {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Car Management");
        frame.setSize(600, 700);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Car Information
        JLabel vinLabel = new JLabel("VIN:");
        vinLabel.setBounds(20, 20, 100, 25);
        JTextField vinField = new JTextField();
        vinField.setBounds(120, 20, 150, 25);

        JLabel makeLabel = new JLabel("Make:");
        makeLabel.setBounds(20, 60, 100, 25);
        JTextField makeField = new JTextField();
        makeField.setBounds(120, 60, 150, 25);

        JLabel modelLabel = new JLabel("Model:");
        modelLabel.setBounds(20, 100, 100, 25);
        JTextField modelField = new JTextField();
        modelField.setBounds(120, 100, 150, 25);

        JLabel yearLabel = new JLabel("Year:");
        yearLabel.setBounds(20, 140, 100, 25);
        JTextField yearField = new JTextField();
        yearField.setBounds(120, 140, 150, 25);

        JLabel priceLabel = new JLabel("Price:");
        priceLabel.setBounds(20, 180, 100, 25);
        JTextField priceField = new JTextField();
        priceField.setBounds(120, 180, 150, 25);

        // Add, Show, Search, Delete Buttons
        JButton addButton = new JButton("Add Car");
        addButton.setBounds(20, 220, 120, 30);

        JButton refreshButton = new JButton("Show Cars");
        refreshButton.setBounds(160, 220, 120, 30);

        JButton searchButton = new JButton("Search Car");
        searchButton.setBounds(20, 260, 120, 30);

        JButton deleteButton = new JButton("Delete Car");
        deleteButton.setBounds(160, 260, 120, 30);

        // Scroll Pane for Car Display
        JTextArea carDisplay = new JTextArea();
        carDisplay.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(carDisplay);
        scrollPane.setBounds(50, 300, 450, 200);
        scrollPane.setVisible(false);

        // Add Car Logic
        CarDAO carDAO = new CarDAO();
        addButton.addActionListener(e -> {
            String vin = vinField.getText();
            String make = makeField.getText();
            String model = modelField.getText();
            String year = yearField.getText();
            String price = priceField.getText();

            if (!vin.isEmpty() && !make.isEmpty() && !model.isEmpty() && !year.isEmpty() && !price.isEmpty()) {
                carDAO.createCar(vin, make, model, Integer.parseInt(year), Double.parseDouble(price));
                vinField.setText("");
                makeField.setText("");
                modelField.setText("");
                yearField.setText("");
                priceField.setText("");
                JOptionPane.showMessageDialog(frame, "Car added successfully!");
            } else {
                JOptionPane.showMessageDialog(frame, "All fields are required!");
            }
        });

        // Show Cars Logic
        refreshButton.addActionListener(e -> {
            scrollPane.setVisible(true);
            carDisplay.setText("");
            StringBuilder cars = carDAO.readCarsToString();
            carDisplay.setText(cars.toString());
        });

        // Search Car Logic
        searchButton.addActionListener(e -> {
            String vin = vinField.getText();
            if (!vin.isEmpty()) {
                scrollPane.setVisible(true);
                carDisplay.setText("");
                StringBuilder result = carDAO.readCarByVINToString(vin);
                carDisplay.setText(result.toString());
            } else {
                JOptionPane.showMessageDialog(frame, "Please enter a VIN!");
            }
        });

        // Delete Car Logic
        deleteButton.addActionListener(e -> {
            String vin = vinField.getText();
            if (!vin.isEmpty()) {
                carDAO.deleteCar(vin);
                vinField.setText("");
                JOptionPane.showMessageDialog(frame, "Car deleted successfully!");
            } else {
                JOptionPane.showMessageDialog(frame, "Please enter a VIN!");
            }
        });

        // Add components to frame
        frame.add(vinLabel);
        frame.add(vinField);
        frame.add(makeLabel);
        frame.add(makeField);
        frame.add(modelLabel);
        frame.add(modelField);
        frame.add(yearLabel);
        frame.add(yearField);
        frame.add(priceLabel);
        frame.add(priceField);
        frame.add(addButton);
        frame.add(refreshButton);
        frame.add(searchButton);
        frame.add(deleteButton);
        frame.add(scrollPane);

        frame.setLayout(null);
        frame.setVisible(true);
    }
}
