import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class CarDAO {

    // Read all cars
    public StringBuilder readCarsToString() {
        String query = "SELECT CarID, VIN, Make, Model, [Year], Price FROM Car";
        StringBuilder result = new StringBuilder();

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                result.append("CarID: ").append(rs.getInt("CarID"))
                        .append(", VIN: ").append(rs.getString("VIN"))
                        .append(", Make: ").append(rs.getString("Make"))
                        .append(", Model: ").append(rs.getString("Model"))
                        .append(", Year: ").append(rs.getInt("Year"))
                        .append(", Price: $").append(rs.getDouble("Price"))
                        .append("\n");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result.length() > 0 ? result : new StringBuilder("No cars found.");
    }

    // Read car by VIN
    public StringBuilder readCarByVINToString(String vin) {
        String query = "SELECT CarID, VIN, Make, Model, [Year], Price FROM Car WHERE VIN = ?";
        StringBuilder result = new StringBuilder();

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, vin);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    result.append("CarID: ").append(rs.getInt("CarID"))
                            .append(", VIN: ").append(rs.getString("VIN"))
                            .append(", Make: ").append(rs.getString("Make"))
                            .append(", Model: ").append(rs.getString("Model"))
                            .append(", Year: ").append(rs.getInt("Year"))
                            .append(", Price: $").append(rs.getDouble("Price"))
                            .append("\n");
                } else {
                    result.append("No car found with VIN: ").append(vin);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    // Create a new car
    public void createCar(String vin, String make, String model, int year, double price) {
        String query = "INSERT INTO Car (VIN, Make, Model, [Year], Price) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, vin);
            stmt.setString(2, make);
            stmt.setString(3, model);
            stmt.setInt(4, year);
            stmt.setDouble(5, price);

            stmt.executeUpdate();
            System.out.println("New car added successfully!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Delete a car by VIN
    public void deleteCar(String vin) {
        String query = "DELETE FROM Car WHERE VIN = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, vin);
            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Car with VIN " + vin + " deleted successfully!");
            } else {
                System.out.println("No car found with VIN " + vin + ".");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
