import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CarServicingDAO {

    public void createCarServicing(String serviceDate, String serviceDescription, double serviceCost, int carId, int appointmentId, int partId) {
        String query = "INSERT INTO CarServicing (ServiceDate, ServiceDescription, ServiceCost, CarID, AppointmentID, PartID) " +
                "VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, serviceDate);
            stmt.setString(2, serviceDescription);
            stmt.setDouble(3, serviceCost);
            stmt.setObject(4, carId > 0 ? carId : null); // Allow null CarID
            stmt.setInt(5, appointmentId);
            stmt.setObject(6, partId > 0 ? partId : null); // Allow null PartID
            stmt.executeUpdate();
            System.out.println("Car servicing record added successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public StringBuilder readCarServicingToString() {
        String query = "SELECT ServiceID, ServiceDate, ServiceDescription, ServiceCost, CarID, AppointmentID, PartID FROM CarServicing";
        StringBuilder result = new StringBuilder();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                result.append("Service ID: ").append(rs.getInt("ServiceID"))
                        .append(", Date: ").append(rs.getDate("ServiceDate"))
                        .append(", Description: ").append(rs.getString("ServiceDescription"))
                        .append(", Cost: $").append(rs.getDouble("ServiceCost"))
                        .append(", Car ID: ").append(rs.getObject("CarID"))
                        .append(", Appointment ID: ").append(rs.getInt("AppointmentID"))
                        .append(", Part ID: ").append(rs.getObject("PartID"))
                        .append("\n");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result.length() > 0 ? result : new StringBuilder("No car servicing records found.");
    }

    public void deleteCarServicing(int serviceId) {
        String query = "DELETE FROM CarServicing WHERE ServiceID = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, serviceId);
            stmt.executeUpdate();
            System.out.println("Car servicing record deleted successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
