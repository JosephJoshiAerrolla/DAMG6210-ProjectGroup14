import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CarServicingGUI {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Car Servicing Management");
        frame.setSize(700, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Car Servicing Components
        JLabel serviceDateLabel = new JLabel("Service Date (YYYY-MM-DD):");
        serviceDateLabel.setBounds(20, 20, 200, 25);
        JTextField serviceDateField = new JTextField();
        serviceDateField.setBounds(220, 20, 150, 25);

        JLabel serviceDescriptionLabel = new JLabel("Service Description:");
        serviceDescriptionLabel.setBounds(20, 60, 200, 25);
        JTextField serviceDescriptionField = new JTextField();
        serviceDescriptionField.setBounds(220, 60, 150, 25);

        JLabel serviceCostLabel = new JLabel("Service Cost:");
        serviceCostLabel.setBounds(20, 100, 200, 25);
        JTextField serviceCostField = new JTextField();
        serviceCostField.setBounds(220, 100, 150, 25);

        JLabel carIdLabel = new JLabel("Car ID (optional):");
        carIdLabel.setBounds(20, 140, 200, 25);
        JTextField carIdField = new JTextField();
        carIdField.setBounds(220, 140, 150, 25);

        JLabel appointmentIdLabel = new JLabel("Appointment ID:");
        appointmentIdLabel.setBounds(20, 180, 200, 25);
        JTextField appointmentIdField = new JTextField();
        appointmentIdField.setBounds(220, 180, 150, 25);

        JLabel partIdLabel = new JLabel("Part ID (optional):");
        partIdLabel.setBounds(20, 220, 200, 25);
        JTextField partIdField = new JTextField();
        partIdField.setBounds(220, 220, 150, 25);

        JButton addServiceButton = new JButton("Add Service");
        addServiceButton.setBounds(20, 260, 150, 30);

        JButton refreshButton = new JButton("Show Services");
        refreshButton.setBounds(200, 260, 150, 30);

        JButton deleteButton = new JButton("Delete Service");
        deleteButton.setBounds(380, 260, 150, 30);

        JTextArea serviceDisplay = new JTextArea();
        serviceDisplay.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(serviceDisplay);
        scrollPane.setBounds(20, 310, 640, 230);

        // Add Components to Frame
        frame.setLayout(null);
        frame.add(serviceDateLabel);
        frame.add(serviceDateField);
        frame.add(serviceDescriptionLabel);
        frame.add(serviceDescriptionField);
        frame.add(serviceCostLabel);
        frame.add(serviceCostField);
        frame.add(carIdLabel);
        frame.add(carIdField);
        frame.add(appointmentIdLabel);
        frame.add(appointmentIdField);
        frame.add(partIdLabel);
        frame.add(partIdField);
        frame.add(addServiceButton);
        frame.add(refreshButton);
        frame.add(deleteButton);
        frame.add(scrollPane);

        // DAO for CarServicing
        CarServicingDAO carServicingDAO = new CarServicingDAO();

        // Add Service Logic
        addServiceButton.addActionListener(e -> {
            String serviceDate = serviceDateField.getText();
            String serviceDescription = serviceDescriptionField.getText();
            double serviceCost = Double.parseDouble(serviceCostField.getText());
            int carId = carIdField.getText().isEmpty() ? 0 : Integer.parseInt(carIdField.getText());
            int appointmentId = Integer.parseInt(appointmentIdField.getText());
            int partId = partIdField.getText().isEmpty() ? 0 : Integer.parseInt(partIdField.getText());

            carServicingDAO.createCarServicing(serviceDate, serviceDescription, serviceCost, carId, appointmentId, partId);
            JOptionPane.showMessageDialog(frame, "Car servicing record added successfully!");
        });

        // Refresh Button Logic
        refreshButton.addActionListener(e -> {
            serviceDisplay.setText(carServicingDAO.readCarServicingToString().toString());
        });

        // Delete Service Logic
        deleteButton.addActionListener(e -> {
            String serviceIdStr = JOptionPane.showInputDialog(frame, "Enter Service ID to delete:");
            if (serviceIdStr != null) {
                int serviceId = Integer.parseInt(serviceIdStr);
                carServicingDAO.deleteCarServicing(serviceId);
                JOptionPane.showMessageDialog(frame, "Car servicing record deleted successfully!");
            }
        });

        frame.setVisible(true);
    }
}
