import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UserDAO {
    public StringBuilder readUsersToString() {
        String query = "SELECT UserID, FirstName, LastName, Email FROM [User]";
        StringBuilder result = new StringBuilder();

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                result.append("ID: ").append(rs.getInt("UserID"))
                        .append(", Name: ").append(rs.getString("FirstName"))
                        .append(" ").append(rs.getString("LastName"))
                        .append(", Email: ").append(rs.getString("Email"))
                        .append("\n");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }
    public StringBuilder getUsersByPage(int pageNumber, int pageSize) {
        String query = "SELECT UserID, FirstName, LastName, Email FROM [User] " +
                "WHERE IsDeleted = 0 " +
                "ORDER BY UserID OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";
        StringBuilder result = new StringBuilder();

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            int offset = (pageNumber - 1) * pageSize;
            stmt.setInt(1, offset);
            stmt.setInt(2, pageSize);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    result.append("ID: ").append(rs.getInt("UserID"))
                            .append(", Name: ").append(rs.getString("FirstName"))
                            .append(" ").append(rs.getString("LastName"))
                            .append(", Email: ").append(rs.getString("Email"))
                            .append("\n");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result.length() > 0 ? result : new StringBuilder("No users found.");
    }

    public StringBuilder readUserByFirstNameToString(String firstName) {
        String query = "SELECT UserID, FirstName, LastName, Email FROM [User] WHERE FirstName = ?";
        StringBuilder result = new StringBuilder();

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, firstName);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    result.append("ID: ").append(rs.getInt("UserID"))
                            .append(", Name: ").append(rs.getString("FirstName"))
                            .append(" ").append(rs.getString("LastName"))
                            .append(", Email: ").append(rs.getString("Email"))
                            .append("\n");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result.length() > 0 ? result : new StringBuilder("No user found with the given first name.");
    }

        public void createUser(String firstName, String lastName, String email, String state) {
            String insertQuery = "INSERT INTO [User] (FirstName, LastName, Email, State, IsDeleted) VALUES (?, ?, ?, ?, 0)";

            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(insertQuery)) {

                stmt.setString(1, firstName);
                stmt.setString(2, lastName);
                stmt.setString(3, email);
                stmt.setString(4, state);
                stmt.executeUpdate();

                System.out.println("New user added successfully!");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }


        public void readUsers() {
        String query = "SELECT UserID, FirstName, LastName, Email FROM [User] WHERE IsDeleted = 0";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("UserID") +
                        ", Name: " + rs.getString("FirstName") + " " + rs.getString("LastName") +
                        ", Email: " + rs.getString("Email"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void readUserByFirstName(String firstName) {
        String query = "SELECT UserID, FirstName, LastName, Email FROM [User] WHERE FirstName = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            if (conn == null) {
                System.out.println("Failed to connect to the database.");
                return;
            }

            stmt.setString(1, firstName);
            try (ResultSet rs = stmt.executeQuery()) {
                boolean found = false;
                while (rs.next()) {
                    found = true;
                    System.out.println("ID: " + rs.getInt("UserID") +
                            ", Name: " + rs.getString("FirstName") + " " + rs.getString("LastName") +
                            ", Email: " + rs.getString("Email"));
                }
                if (!found) {
                    System.out.println("No user found with the first name: " + firstName);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void updateUser(int userId, String email) {
        String query = "UPDATE [User] SET Email = ? WHERE UserID = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            if (conn == null) {
                System.out.println("Failed to connect to the database.");
                return;
            }

            stmt.setString(1, email);
            stmt.setInt(2, userId);
            stmt.executeUpdate();

            System.out.println("User updated successfully!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void deleteUser(int userId) {
        String query = "DELETE FROM [User] WHERE UserID = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            if (conn == null) {
                System.out.println("Failed to connect to the database.");
                return;
            }

            stmt.setInt(1, userId);
            stmt.executeUpdate();

            System.out.println("User deleted successfully!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
