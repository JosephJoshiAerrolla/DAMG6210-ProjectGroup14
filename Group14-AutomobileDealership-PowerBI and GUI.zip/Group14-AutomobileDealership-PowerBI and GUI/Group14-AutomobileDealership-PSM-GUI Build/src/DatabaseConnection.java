import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    public static Connection getConnection() {
        // enter your url, username, and password for the database
        String url = "jdbc:sqlserver://localhost:1433;databaseName=AutomobileDealership;encrypt=true;trustServerCertificate=true;";
        String username = "AS";
        String password = "54146088";

        try {
            Connection connection = DriverManager.getConnection(url, username, password);
            System.out.println("Connection successful!");
            return connection;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static void main(String[] args) {
        // Test the database connection
        getConnection();
    }
}
