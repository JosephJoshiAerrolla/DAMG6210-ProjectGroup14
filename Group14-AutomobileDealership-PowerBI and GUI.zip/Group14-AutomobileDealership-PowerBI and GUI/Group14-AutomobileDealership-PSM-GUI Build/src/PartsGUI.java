import javax.swing.*;
import java.awt.event.ActionEvent;

public class PartsGUI {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Parts Management");
        frame.setSize(600, 700);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Part Name Label and Field
        JLabel partNameLabel = new JLabel("Part Name:");
        partNameLabel.setBounds(20, 20, 100, 25);
        JTextField partNameField = new JTextField();
        partNameField.setBounds(120, 20, 150, 25);

        // Part Cost Label and Field
        JLabel partCostLabel = new JLabel("Part Cost:");
        partCostLabel.setBounds(20, 60, 100, 25);
        JTextField partCostField = new JTextField();
        partCostField.setBounds(120, 60, 150, 25);

        // Status Label and Field
        JLabel statusLabel = new JLabel("Status:");
        statusLabel.setBounds(20, 100, 100, 25);
        JTextField statusField = new JTextField();
        statusField.setBounds(120, 100, 150, 25);

        // Storage Lot ID Label and Field
        JLabel storageLotLabel = new JLabel("Storage Lot ID:");
        storageLotLabel.setBounds(20, 140, 100, 25);
        JTextField storageLotField = new JTextField();
        storageLotField.setBounds(120, 140, 150, 25);

        // Part ID Label and Field for Deletion
        JLabel partIDLabel = new JLabel("Part ID:");
        partIDLabel.setBounds(20, 180, 100, 25);
        JTextField partIDField = new JTextField();
        partIDField.setBounds(120, 180, 150, 25);

        // Add Part Button
        JButton addButton = new JButton("Add Part");
        addButton.setBounds(20, 220, 120, 30);

        // Show Parts Button
        JButton refreshButton = new JButton("Show Parts");
        refreshButton.setBounds(160, 220, 120, 30);

        // Delete Part Button
        JButton deleteButton = new JButton("Delete Part");
        deleteButton.setBounds(300, 220, 120, 30);

        // Scroll Pane for Part Display
        JTextArea partDisplay = new JTextArea();
        partDisplay.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(partDisplay);
        scrollPane.setBounds(50, 300, 450, 200);
        scrollPane.setVisible(false);

        // Add Part Button Logic
        PartsDAO partsDAO = new PartsDAO();
        addButton.addActionListener((ActionEvent e) -> {
            String partName = partNameField.getText();
            double partCost = Double.parseDouble(partCostField.getText());
            String status = statusField.getText();
            int storageLotID = Integer.parseInt(storageLotField.getText());

            if (!partName.isEmpty() && partCost > 0 && !status.isEmpty() && storageLotID > 0) {
                partsDAO.createPart(partName, partCost, status, storageLotID);
                JOptionPane.showMessageDialog(frame, "Part added successfully!");
            } else {
                JOptionPane.showMessageDialog(frame, "All fields are required!");
            }
        });

        // Refresh Button Logic
        refreshButton.addActionListener((ActionEvent e) -> {
            scrollPane.setVisible(true);
            partDisplay.setText(partsDAO.readPartsToString().toString());
        });

        // Delete Part Button Logic
        deleteButton.addActionListener((ActionEvent e) -> {
            int partID = Integer.parseInt(partIDField.getText());
            if (partID > 0) {
                partsDAO.deletePart(partID);
                JOptionPane.showMessageDialog(frame, "Part deleted successfully!");
            } else {
                JOptionPane.showMessageDialog(frame, "Please enter a valid Part ID!");
            }
        });

        // Add components to frame
        frame.add(partNameLabel);
        frame.add(partNameField);
        frame.add(partCostLabel);
        frame.add(partCostField);
        frame.add(statusLabel);
        frame.add(statusField);
        frame.add(storageLotLabel);
        frame.add(storageLotField);
        frame.add(partIDLabel);
        frame.add(partIDField);
        frame.add(addButton);
        frame.add(refreshButton);
        frame.add(deleteButton);
        frame.add(scrollPane);

        frame.setLayout(null);
        frame.setVisible(true);
    }
}
