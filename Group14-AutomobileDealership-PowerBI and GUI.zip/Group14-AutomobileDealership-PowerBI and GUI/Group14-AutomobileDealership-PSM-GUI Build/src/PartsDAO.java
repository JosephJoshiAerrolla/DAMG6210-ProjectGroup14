import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class PartsDAO {
    public StringBuilder readPartsToString() {
        String query = "SELECT PartID, PartName, PartCost, [Status], StorageLotID FROM Parts";
        StringBuilder result = new StringBuilder();

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                result.append("ID: ").append(rs.getInt("PartID"))
                        .append(", Name: ").append(rs.getString("PartName"))
                        .append(", Cost: ").append(rs.getBigDecimal("PartCost"))
                        .append(", Status: ").append(rs.getString("Status"))
                        .append(", Storage Lot ID: ").append(rs.getInt("StorageLotID"))
                        .append("\n");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    public void createPart(String partName, double partCost, String status, int storageLotID) {
        String insertQuery = "INSERT INTO Parts (PartName, PartCost, [Status], StorageLotID) VALUES (?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(insertQuery)) {

            stmt.setString(1, partName);
            stmt.setDouble(2, partCost);
            stmt.setString(3, status);
            stmt.setInt(4, storageLotID);
            stmt.executeUpdate();

            System.out.println("New part added successfully!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void deletePart(int partID) {
        String deleteQuery = "DELETE FROM Parts WHERE PartID = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(deleteQuery)) {

            stmt.setInt(1, partID);
            stmt.executeUpdate();

            System.out.println("Part deleted successfully!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
