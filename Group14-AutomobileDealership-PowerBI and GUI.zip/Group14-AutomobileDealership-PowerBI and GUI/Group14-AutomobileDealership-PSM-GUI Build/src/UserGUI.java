import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class UserGUI {
    public static void main(String[] args) {
        JFrame frame = new JFrame("User Management");
        frame.setSize(600, 700); // Increase height for better layout
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // First Name Label and Field
        JLabel firstNameLabel = new JLabel("First Name:");
        firstNameLabel.setBounds(20, 20, 100, 25);
        JTextField firstNameField = new JTextField();
        firstNameField.setBounds(120, 20, 150, 25);

        // Last Name Label and Field
        JLabel lastNameLabel = new JLabel("Last Name:");
        lastNameLabel.setBounds(20, 60, 100, 25);
        JTextField lastNameField = new JTextField();
        lastNameField.setBounds(120, 60, 150, 25);

        // Email Label and Field
        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setBounds(20, 100, 100, 25);
        JTextField emailField = new JTextField();
        emailField.setBounds(120, 100, 150, 25);

        // User ID Label and Field
        JLabel userIdLabel = new JLabel("User ID:");
        userIdLabel.setBounds(20, 140, 100, 25);
        JTextField userIdField = new JTextField();
        userIdField.setBounds(120, 140, 150, 25);

        // State Label and Field (Hidden)
        JLabel stateLabel = new JLabel("State:");
        stateLabel.setBounds(20, 180, 100, 25);
        JTextField stateField = new JTextField();
        stateField.setBounds(120, 180, 150, 25);
        stateLabel.setVisible(false); // Hide the State label
        stateField.setVisible(false); // Hide the State field

        // Add User Button
        JButton addButton = new JButton("Add User");
        addButton.setBounds(20, 220, 120, 30);

        // Show Users Button
        JButton refreshButton = new JButton("Show Users");
        refreshButton.setBounds(160, 220, 120, 30);

        // Search User Button
        JButton searchButton = new JButton("Search User");
        searchButton.setBounds(20, 260, 120, 30);

        // Delete User Button
        JButton deleteButton = new JButton("Delete User");
        deleteButton.setBounds(160, 260, 120, 30);

        // Scroll Pane for User Display
        JTextArea userDisplay = new JTextArea();
        userDisplay.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(userDisplay);
        scrollPane.setBounds(50, 300, 450, 200);
        scrollPane.setVisible(false); // Initially hidden

        // Add User Button Logic
        UserDAO userDAO = new UserDAO();
        addButton.addActionListener(e -> {
            String firstName = firstNameField.getText();
            String lastName = lastNameField.getText();
            String email = emailField.getText();

            // Use stateField if needed, even though it is hidden
            String state = stateField.getText().isEmpty() ? "DefaultState" : stateField.getText();

            if (!firstName.isEmpty() && !lastName.isEmpty() && !email.isEmpty()) {
                userDAO.createUser(firstName, lastName, email, state); // Include state in logic
                firstNameField.setText("");
                lastNameField.setText("");
                emailField.setText("");
                JOptionPane.showMessageDialog(frame, "User added successfully!");
            } else {
                JOptionPane.showMessageDialog(frame, "All fields are required!");
            }
        });

        // Refresh Button Logic
        refreshButton.addActionListener(e -> {
            scrollPane.setVisible(true); // Show the scroll pane
            userDisplay.setText(""); // Clear previous content
            StringBuilder users = userDAO.readUsersToString();
            userDisplay.setText(users.toString());
        });

        // Search Button Logic
        searchButton.addActionListener(e -> {
            String firstName = firstNameField.getText();
            if (!firstName.isEmpty()) {
                scrollPane.setVisible(true); // Show the scroll pane
                userDisplay.setText(""); // Clear previous content
                StringBuilder result = userDAO.readUserByFirstNameToString(firstName);
                userDisplay.setText(result.toString());
            } else {
                JOptionPane.showMessageDialog(frame, "Please enter a first name!");
            }
        });

        // Delete Button Logic
        deleteButton.addActionListener(e -> {
            String userId = userIdField.getText();
            if (!userId.isEmpty()) {
                userDAO.deleteUser(Integer.parseInt(userId));
                userIdField.setText("");
                JOptionPane.showMessageDialog(frame, "User deleted successfully!");
            } else {
                JOptionPane.showMessageDialog(frame, "Please enter a User ID!");
            }
        });

        // Add components to frame
        frame.add(firstNameLabel);
        frame.add(firstNameField);
        frame.add(lastNameLabel);
        frame.add(lastNameField);
        frame.add(emailLabel);
        frame.add(emailField);
        frame.add(userIdLabel);
        frame.add(userIdField);
        frame.add(stateLabel); // Add state label (hidden)
        frame.add(stateField); // Add state field (hidden)
        frame.add(addButton);
        frame.add(refreshButton);
        frame.add(searchButton);
        frame.add(deleteButton);
        frame.add(scrollPane); // Add scroll pane

        frame.setLayout(null);
        frame.setVisible(true);
    }
}
